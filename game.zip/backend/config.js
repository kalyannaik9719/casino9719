module.exports = {
    port: 5000,
    dbConnectionString: 'mongodb://localhost:27017/casino-app',
    secretKey: 'your_secret_key',
    paymentGateway: {
        apiKey: 'your_api_key',
        secret: 'your_secret'
    }
};