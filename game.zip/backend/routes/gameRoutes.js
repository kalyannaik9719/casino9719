const express = require('express');
const router = express.Router();
const Game = require('../models/Game');

// Add routes for fetching games, etc.

module.exports = router;