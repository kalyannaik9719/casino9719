# Casino App

This is a casino application with a paywall feature.

## Getting Started

### Backend

1. Install dependencies:
    ```sh
    cd backend
    npm install
    ```

2. Start the backend server:
    ```sh
    npm start
    ```

### Frontend

1. Install dependencies:
    ```sh
    cd frontend
    npm install
    ```

2. Start the frontend server:
    ```sh
    npm start
    ```

## Features

- User registration and login
- Game listing
- Paywall integration

## License

This project is licensed under the MIT License.