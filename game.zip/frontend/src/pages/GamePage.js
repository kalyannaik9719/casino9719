import React from 'react';

function GamePage() {
  return (
    <div className="container">
      <header>
        <h1>Games</h1>
      </header>
      <main>
        <h2>Game List</h2>
        <p>Here you can find a list of games to play.</p>
      </main>
    </div>
  );
}

export default GamePage;