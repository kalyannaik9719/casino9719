import React from 'react';

function HomePage() {
  return (
    <div className="container">
      <header>
        <h1>Casino App</h1>
      </header>
      <main>
        <h2>Welcome to the Casino App</h2>
        <p>Please login or register to play games.</p>
      </main>
    </div>
  );
}

export default HomePage;