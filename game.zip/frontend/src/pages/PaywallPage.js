import React from 'react';

function PaywallPage() {
  return (
    <div className="container">
      <header>
        <h1>Paywall</h1>
      </header>
      <main>
        <h2>Access Premium Features</h2>
        <p>To access premium features, please make a payment.</p>
        <button>Pay Now</button>
      </main>
    </div>
  );
}

export default PaywallPage;